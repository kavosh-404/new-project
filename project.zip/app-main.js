/**
 * script.js
 * Main orchestrator for the mate choice simulation UI and chat system
 * Uses the modular SimulationEngine for core logic
 */

class MateChoiceSimulation {
    constructor() {
      // Initialize simulation engine (pure logic)
      this.engine = new SimulationEngine(500);

      this.canvas = document.getElementById("simulation-canvas");
      this.context = this.canvas.getContext("2d");
      this.simulationGridSection = this.canvas
        ? this.canvas.closest(".simulation-grid") || this.canvas
        : null;
      this.preferenceSelect = document.getElementById("preference-rule");
      this.mobilitySelect = document.getElementById("mobility-level");
      this.densitySelect = document.getElementById("density-level");
      this.selectivitySelect = document.getElementById("selectivity-level");
      this.patienceSelect = document.getElementById("patience-level");
      this.explorationSelect = document.getElementById("exploration-level");
      this.runButton = document.getElementById("run-simulation");
      this.status = document.getElementById("simulation-status");
      this.teachingExplanation = document.getElementById("teaching-explanation");
      this.teachingSimpleToggle = document.getElementById("teaching-simple-toggle");
      this.chatLog = document.getElementById("chat-log");
      this.chatSuggestions = document.getElementById("chat-suggestions");
      this.chatForm = document.getElementById("chat-form");
      this.chatInput = document.getElementById("chat-input");
      this.chatSimpleToggle = document.getElementById("chat-simple-toggle");
      this.chatCapabilitiesButton = document.getElementById("chat-capabilities");
      this.chatResetButton = document.getElementById("chat-reset");
      this.previewCsvButton = document.getElementById("preview-csv");
      this.downloadCsvButton = document.getElementById("download-csv");
      this.downloadPngButton = document.getElementById("download-png");
      this.copyCitationButton = document.getElementById("copy-citation");
      this.batchRunCountSelect = document.getElementById("batch-run-count");
      this.runBatchButton = document.getElementById("run-batch");
      this.batchSummary = document.getElementById("batch-summary");
      this.csvPreview = document.getElementById("csv-preview");
      this.csvPreviewContent = document.getElementById("csv-preview-content");
      this.previewIntroText = document.getElementById("preview-intro-text");
      this.previewBodyText = document.getElementById("preview-body-text");
      this.previewConclusionText = document.getElementById("preview-conclusion-text");
      this.previewKpiPairs = document.getElementById("preview-kpi-pairs");
      this.previewKpiStrength = document.getElementById("preview-kpi-strength");
      this.previewKpiSearch = document.getElementById("preview-kpi-search");
      this.previewMetricsChart = document.getElementById("preview-metrics-chart");
      this.previewDifferenceChart = document.getElementById("preview-difference-chart");
      this.previewMetricsInsight = document.getElementById("preview-metrics-insight");
      this.previewDifferenceInsight = document.getElementById("preview-difference-insight");
      this.ruleAnalyticsDefinitions = document.getElementById("rule-analytics-definitions");
      this.ruleCodeExplainer = document.getElementById("rule-code-explainer");
      this.ruleAnalyticsBody = document.getElementById("rule-analytics-body");
      this.ruleHazardChart = document.getElementById("rule-hazard-chart");
      this.ruleHazardZoomChart = document.getElementById("rule-hazard-zoom-chart");
      this.ruleHazardInsight = document.getElementById("rule-hazard-insight");
      this.ruleHazardTooltip = document.getElementById("rule-hazard-tooltip");
      this.ruleHazardZoomTooltip = document.getElementById("rule-hazard-zoom-tooltip");
      this.hazardChartMode = document.getElementById("hazard-chart-mode");
      this.hazardSeriesToggles = document.getElementById("hazard-series-toggles");
      this.hazardSelectAllButton = document.getElementById("hazard-select-all");
      this.hazardClearAllButton = document.getElementById("hazard-clear-all");
      this.hazardAutoTop2 = document.getElementById("hazard-auto-top2");
      this.hazardAutoTopN = document.getElementById("hazard-auto-topn");
      this.hazardDynamicExplainer = document.getElementById("hazard-dynamic-explainer");
      this.recreatedFigure5Chart = document.getElementById("recreated-figure5-chart");
      this.recreatedFigure6Chart = document.getElementById("recreated-figure6-chart");
      this.recreatedFigure7Chart = document.getElementById("recreated-figure7-chart");
      this.recreatedFigure5Insight = document.getElementById("recreated-figure5-insight");
      this.recreatedFigure6Insight = document.getElementById("recreated-figure6-insight");
      this.recreatedFigure7Insight = document.getElementById("recreated-figure7-insight");
      this.summaryPairs = document.getElementById("summary-pairs");
      this.summaryStrength = document.getElementById("summary-strength");
      this.summarySearch = document.getElementById("summary-search");
      this.runSummary = document.getElementById("run-summary");
      this.runComparisonPanel = document.getElementById("run-comparison-panel");
      this.runComparisonBody = document.getElementById("run-comparison-body");
      this.runComparisonSummary = document.getElementById("run-comparison-summary");
      this.clearRunComparisonButton = document.getElementById("clear-run-comparison");
      this.lessonPresetStatus = document.getElementById("lesson-preset-status");
      this.lessonPresetButtons = Array.from(document.querySelectorAll("[data-preset]"));
      this.controlHelpButtons = Array.from(document.querySelectorAll(".control-help"));

      this.state = {
        agents: [],
        pairs: [],
        step: 0,
        isRunning: false,
        lastRun: null,
      };

      if (this.chatResetButton) {
        this.chatResetButton.addEventListener("click", () => this.resetChatSession());
      }
      if (this.chatSimpleToggle) {
        this.chatSimpleToggle.addEventListener("change", () => {
          this.setSimpleMode(this.chatSimpleToggle.checked, {
            announceInChat: true,
            refreshTeachingPanel: true,
          });
        });
      }
      if (this.teachingSimpleToggle) {
        this.teachingSimpleToggle.addEventListener("change", () => {
          this.setSimpleMode(this.teachingSimpleToggle.checked, {
            announceInChat: false,
            refreshTeachingPanel: true,
          });
        });
      }
      if (this.downloadCsvButton) {
        this.downloadCsvButton.addEventListener("click", () => this.downloadCsv());
      }
      if (this.previewCsvButton) {
        this.previewCsvButton.addEventListener("click", () => this.previewCsv());
      }
      if (this.downloadPngButton) {
        this.downloadPngButton.addEventListener("click", () => this.downloadPng());
      }
      if (this.copyCitationButton) {
        this.copyCitationButton.addEventListener("click", () => this.copyCitation());
      }
      if (this.clearRunComparisonButton) {
        this.clearRunComparisonButton.addEventListener("click", () => this.clearRunComparison());
      }
      this.bindLessonPresets();
    }

    bindControlHelpTooltips() {
      if (!this.controlHelpButtons.length) return;

      this.controlHelpButtons.forEach((button) => {
        button.addEventListener("click", (event) => {
          event.stopPropagation();
          const willOpen = !button.classList.contains("is-open");
          this.closeControlHelpTooltips();
          if (willOpen) {
            button.classList.add("is-open");
            button.setAttribute("aria-expanded", "true");
          }
        });
      });

      document.addEventListener("click", this.handleControlHelpDocumentClick);
      document.addEventListener("keydown", this.handleControlHelpKeydown);
    }

    closeControlHelpTooltips() {
      this.controlHelpButtons.forEach((button) => {
        button.classList.remove("is-open");
        button.setAttribute("aria-expanded", "false");
      });
    }

    handleControlHelpDocumentClick(event) {
      if (!event.target.closest(".control-help")) {
        this.closeControlHelpTooltips();
      }
    }

    handleControlHelpKeydown(event) {
      if (event.key === "Escape") {
        this.closeControlHelpTooltips();
      }
    }

    handleResize() {
      const rect = this.canvas.getBoundingClientRect();
      const size = Math.max(320, Math.floor(Math.min(rect.width || 0, rect.height || rect.width || 0)));
      const ratio = window.devicePixelRatio || 1;

      this.canvas.width = size * ratio;
      this.canvas.height = size * ratio;
      this.context.setTransform(1, 0, 0, 1, 0, 0);
      this.context.scale(ratio, ratio);

      if (this.state.agents.length > 0) {
        this.draw();
      }
    }

    seedPreview() {
      this.state.agents = this.createAgents(this.getDensityCount(this.densitySelect.value));
      this.state.pairs = [];
      this.state.step = 0;
      this.draw();
    }

    handleRun() {
      if (this.state.isRunning) {
        return;
      }

      this.scrollToSimulationGrid();

      if (this.batchSummary) {
        this.batchSummary.classList.remove("is-visible");
        this.batchSummary.textContent = "";
      }
      if (this.csvPreview) {
        this.csvPreview.classList.remove("is-visible");
      }
      this.resetPreviewContent();

      this.state = {
        agents: this.createAgents(this.getDensityCount(this.densitySelect.value)),
        pairs: [],
        step: 0,
        isRunning: true,
      };

      this.runButton.disabled = true;
      this.status.textContent = "Simulation started. Agents are moving into their first encounters.";
      this.draw();
      this.animate();
    }

    handleBatchRun() {
      if (this.state.isRunning) {
        return;
      }

      const runCount = parseInt(this.batchRunCountSelect ? this.batchRunCountSelect.value : "30", 10) || 30;
      const metricsList = [];

      this.runButton.disabled = true;
      if (this.runBatchButton) this.runBatchButton.disabled = true;
      this.status.textContent = "Running batch experiment: " + runCount + " simulations...";

      for (let runIndex = 0; runIndex < runCount; runIndex += 1) {
        this.state = {
          agents: this.createAgents(this.getDensityCount(this.densitySelect.value)),
          pairs: [],
          step: 0,
          isRunning: false,
          lastRun: this.state.lastRun,
        };

        for (let stepIndex = 0; stepIndex < STEP_COUNT; stepIndex += 1) {
          this.stepSimulation();
          this.state.step = stepIndex + 1;
        }

        metricsList.push(this.getSimulationMetrics());
      }

      const pairStats = this.computeBatchStats(metricsList.map((m) => m.pairCount));
      const strengthStats = this.computeBatchStats(metricsList.map((m) => m.matchingStrength));
      const searchStats = this.computeBatchStats(metricsList.map((m) => m.averageSearchSteps));
      const lastMetrics = metricsList[metricsList.length - 1];

      this.state.lastRun = {
        metrics: lastMetrics,
        mobilityLevel: this.mobilitySelect.value,
        densityLevel: this.densitySelect.value,
        preferenceRule: this.preferenceSelect.value,
        selectivityLevel: this.selectivitySelect ? this.selectivitySelect.value : "Medium",
        patienceLevel: this.patienceSelect ? this.patienceSelect.value : "Normal",
        explorationLevel: this.explorationSelect ? this.explorationSelect.value : "Balanced",
      };

      this.lastCitation = this.buildRunCitationMessage(
        this.state.lastRun.metrics,
        this.state.lastRun.mobilityLevel,
        this.state.lastRun.densityLevel,
        this.state.lastRun.preferenceRule,
        this.state.lastRun.selectivityLevel,
        this.state.lastRun.patienceLevel,
        this.state.lastRun.explorationLevel
      );

      this.updateSummaryBar();
      this.setExportEnabled(true);
      this.renderInsightQuestions();
      this.draw();
      this.showBatchSummary(runCount, pairStats, strengthStats, searchStats);

      this.status.textContent =
        "Batch complete: " +
        runCount +
        " runs. Mean pairs " +
        pairStats.mean.toFixed(1) +
        ", mean strength " +
        strengthStats.mean.toFixed(2) +
        ", mean search " +
        searchStats.mean.toFixed(1) +
        ".";

      this.addChatMessage(
        "Assistant",
        "Batch experiment complete (n=" +
          runCount +
          "). Mean pairs=" +
          pairStats.mean.toFixed(1) +
          " (95% CI " +
          pairStats.ciLow.toFixed(1) +
          " to " +
          pairStats.ciHigh.toFixed(1) +
          "), matching strength=" +
          strengthStats.mean.toFixed(2) +
          " (95% CI " +
          strengthStats.ciLow.toFixed(2) +
          " to " +
          strengthStats.ciHigh.toFixed(2) +
          "), avg search=" +
          searchStats.mean.toFixed(1) +
          " (95% CI " +
          searchStats.ciLow.toFixed(1) +
          " to " +
          searchStats.ciHigh.toFixed(1) +
          ")."
      );

      this.runButton.disabled = false;
      if (this.runBatchButton) this.runBatchButton.disabled = false;
    }

    computeBatchStats(values) {
      const n = values.length;
      if (!n) {
        return { mean: 0, sd: 0, ciLow: 0, ciHigh: 0 };
      }

      const mean = values.reduce((sum, value) => sum + value, 0) / n;
      const variance =
        n > 1
          ? values.reduce((sum, value) => sum + Math.pow(value - mean, 2), 0) / (n - 1)
          : 0;
      const sd = Math.sqrt(variance);
      const margin = n > 1 ? 1.96 * (sd / Math.sqrt(n)) : 0;

      return {
        mean,
        sd,
        ciLow: mean - margin,
        ciHigh: mean + margin,
      };
    }

    showBatchSummary(runCount, pairStats, strengthStats, searchStats) {
      if (!this.batchSummary) return;

      this.batchSummary.innerHTML =
        "Batch n=" +
        runCount +
        " | Pairs mean=" +
        pairStats.mean.toFixed(1) +
        " (95% CI " +
        pairStats.ciLow.toFixed(1) +
        " to " +
        pairStats.ciHigh.toFixed(1) +
        ") | Strength mean=" +
        strengthStats.mean.toFixed(2) +
        " (95% CI " +
        strengthStats.ciLow.toFixed(2) +
        " to " +
        strengthStats.ciHigh.toFixed(2) +
        ") | Avg search mean=" +
        searchStats.mean.toFixed(1) +
        " (95% CI " +
        searchStats.ciLow.toFixed(1) +
        " to " +
        searchStats.ciHigh.toFixed(1) +
        ").";
      this.batchSummary.classList.add("is-visible");
    }

    handleControlChange() {
      if (this.debounceTimer) {
        window.clearTimeout(this.debounceTimer);
      }

      this.debounceTimer = window.setTimeout(() => {
        this.debounceTimer = null;

        if (!this.state.isRunning) {
          this.handleRun();
        }
      }, 400);
    }

    handleChatSubmit(event) {
      event.preventDefault();
      const text = (this.chatInput.value || "").trim();
      if (!text) return;

      this.chatInput.value = "";
      this.submitChatQuestion(text);
    }

    submitChatQuestion(text) {
      this.addChatMessage("You", text);
      const reply = this.buildChatReply(text);
      this.addChatMessage("Assistant", reply);
      this.renderInsightQuestions();
    }

    resetChatSession() {
      if (this.chatLog) {
        this.chatLog.innerHTML = "";
      }

      this.conversationHistory = [];
      this.lastTopic = null;
      this.lastQuestionType = null;
      this.topicDepth = 0;

      this.addChatMessage(
        "Assistant",
        this.state.lastRun
          ? "Chat reset. Ask about this scenario's density, mobility, preference rule, matching strength, or citations."
          : "Chat reset. Run a scenario, then ask about density, mobility, preference rules, matching, or citations."
      );
      this.renderInsightQuestions();
    }

    createAgents(count) {
      const size = this.getCanvasSize();
      const padding = AGENT_RADIUS + 4;
      const agents = [];

      for (let index = 0; index < count; index += 1) {
        agents.push({
          id: index,
          attractiveness: this.randomInt(1, 10),
          x: this.randomFloat(padding, size - padding),
          y: this.randomFloat(padding, size - padding),
          matched: false,
          partnerId: null,
          matchedAtStep: null,
          searchSteps: 0,
        });
      }

      return agents;
    }

    animate() {
      if (!this.state.isRunning) {
        return;
      }

      if (this.state.step >= STEP_COUNT) {
        this.finishRun();
        return;
      }

      this.stepSimulation();
      this.draw();
      this.state.step += 1;
      this.updateStatus();

      window.requestAnimationFrame(() => this.animate());
    }

    stepSimulation() {
      const currentStep = this.state.step + 1;
      this.moveAgents();
      this.resolveEncounters(currentStep);

      this.state.agents.forEach((agent) => {
        if (!agent.matched) {
          agent.searchSteps += 1;
        }
      });
    }

    moveAgents() {
      const movement = mobilitySizes[this.mobilitySelect.value];
      const exploration = explorationMultipliers[this.explorationSelect ? this.explorationSelect.value : "Balanced"] || 1;
      const movementRange = movement * exploration;
      const size = this.getCanvasSize();
      const padding = AGENT_RADIUS + 2;

      this.state.agents.forEach((agent) => {
        if (agent.matched) {
          return;
        }

        agent.x = this.clamp(agent.x + this.randomFloat(-movementRange, movementRange), padding, size - padding);
        agent.y = this.clamp(agent.y + this.randomFloat(-movementRange, movementRange), padding, size - padding);
      });
    }

    resolveEncounters(currentStep) {
      const unmatchedAgents = this.shuffle(this.state.agents.filter((agent) => !agent.matched));

      for (let index = 0; index < unmatchedAgents.length; index += 1) {
        const agent = unmatchedAgents[index];

        if (agent.matched) {
          continue;
        }

        for (let otherIndex = index + 1; otherIndex < unmatchedAgents.length; otherIndex += 1) {
          const candidate = unmatchedAgents[otherIndex];

          if (candidate.matched) {
            continue;
          }

          if (this.getDistance(agent, candidate) > ENCOUNTER_DISTANCE) {
            continue;
          }

          if (this.mutuallyAccept(agent, candidate)) {
            this.matchAgents(agent, candidate, currentStep);
            break;
          }
        }
      }
    }

    mutuallyAccept(agent, candidate) {
      const preferenceRule = this.preferenceSelect.value;
      const agentAcceptance = this.getAcceptanceScore(agent, candidate, preferenceRule);
      const candidateAcceptance = this.getAcceptanceScore(candidate, agent, preferenceRule);

      return Math.random() < agentAcceptance && Math.random() < candidateAcceptance;
    }

    getAcceptanceScore(agent, candidate, preferenceRule) {
      const selectivityLevel = this.selectivitySelect ? this.selectivitySelect.value : "Medium";
      const patienceLevel = this.patienceSelect ? this.patienceSelect.value : "Normal";
      return this.getAcceptanceScoreWithSettings(
        agent,
        candidate,
        preferenceRule,
        selectivityLevel,
        patienceLevel
      );
    }

    matchAgents(agent, candidate, stepNumber) {
      agent.matched = true;
      candidate.matched = true;
      agent.partnerId = candidate.id;
      candidate.partnerId = agent.id;
      agent.matchedAtStep = stepNumber;
      candidate.matchedAtStep = stepNumber;

      this.state.pairs.push({ agent1: agent.id, agent2: candidate.id });
    }

    finishRun() {
      this.state.isRunning = false;
      this.runButton.disabled = false;
        this.lastTopic = null;
        this.lastQuestionType = null;
        this.topicDepth = 0;
      this.updateStatus(true);
      this.updateTeachingExplanation();
      this.recordRunForComparison("Single");
      this.setExportEnabled(true);
      this.updateSummaryBar();
      this.autoOpenPreviewReport();
      this.draw();
    }

    autoOpenPreviewReport() {
      const csv = this.buildRunCsvText();
      if (!csv) return;
      this.showCsvPreview(csv);

      if (this.csvPreview && this.csvPreview.scrollIntoView) {
        this.csvPreview.scrollIntoView({ behavior: "smooth", block: "start" });
      }
    }

    scrollToSimulationGrid() {
      if (this.simulationGridSection && this.simulationGridSection.scrollIntoView) {
        this.simulationGridSection.scrollIntoView({ behavior: "smooth", block: "start" });
      }
    }

    updateStatus(isComplete = false) {
      const matchedCount = this.state.agents.filter((agent) => agent.matched).length;
      const pairCount = this.state.pairs.length;

      if (isComplete) {
        this.status.textContent =
          "Simulation complete: " +
          pairCount +
          " pairs formed across " +
          STEP_COUNT +
          " steps with " +
          matchedCount +
          " matched agents.";
        return;
      }

      if (!this.state.isRunning) {
        this.status.textContent =
          "Ready to simulate density, mobility, and mate choice encounters.";
        return;
      }

      this.status.textContent =
        "Running step " +
        this.state.step +
        " of " +
        STEP_COUNT +
        ": " +
        pairCount +
        " pairs formed so far.";
    }

    draw() {
      RenderEngine.draw(this.context, this.state.agents, this.state.pairs, this.canvas.width, this.canvas.height);
    }
          return [
            "How did the " + preferenceRule.toLowerCase() + " rule shape this scenario?",
            "What would likely change under " + alternatePreference + "?",
            "Why did this rule produce matching strength " + matchingStrength + "?",
            "I don't understand.",
          ];
        }

        return [
          "Why did " + densityLevel.toLowerCase() + " density affect pairing in this run?",
          "I don't understand.",
          "How does " + mobilityLevel.toLowerCase() + " mobility vs. " + densityLevel.toLowerCase() + " density differ here?",
          "How did the " + preferenceRule.toLowerCase() + " rule shape the " + pairCount + " pairs we observed?",
          "What result best explains matching strength " + matchingStrength + "?",
        ];
      }

      buildCapabilityMessage() {
        return TeachingContent.buildCapabilityMessage(!!this.state.lastRun);
      }

      buildOutOfScopeReply() {
        return TeachingContent.buildOutOfScopeReply();
      }

    renderInsightQuestions() {
      if (!this.chatSuggestions) return;

      this.chatSuggestions.innerHTML = "";

      const title = document.createElement("p");
      title.className = "chat-suggestions-title";
        if (!this.state.lastRun) {
          title.textContent = "Run a scenario to unlock suggested insight questions";
        } else if (this.lastTopic) {
          title.textContent = "Suggested follow-ups for " + this.getScenarioLabel();
        } else {
          title.textContent = "Insight questions for " + this.getScenarioLabel();
        }
      this.chatSuggestions.appendChild(title);

      const buttons = document.createElement("div");
      buttons.className = "chat-suggestion-buttons";

        this.getInsightQuestionSet().forEach((question) => {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "chat-suggestion-chip";
        button.textContent = question;
        button.disabled = !this.state.lastRun;
        button.addEventListener("click", () => this.submitChatQuestion(question));
        buttons.appendChild(button);
      });

      this.chatSuggestions.appendChild(buttons);
    }

    addChatMessage(author, text) {
      if (!this.chatLog) return;
      const p = document.createElement("p");
      p.className = "chat-message";
      const strong = document.createElement("strong");
      strong.textContent = author + ":";
      p.appendChild(strong);
      p.appendChild(document.createTextNode(" " + text));
      this.chatLog.appendChild(p);
      this.chatLog.scrollTop = this.chatLog.scrollHeight;
    }


    buildChatReply(text) {
      const normalizeDensity = (densityLevel) =>
        densityLevel === "Sparse" ? "Low Density" : densityLevel === "Dense" ? "High Density" : "Normal Density";
      const normalizeMobility = (mobilityLevel) =>
        mobilityLevel === "Low" ? "Low Mobility" : mobilityLevel === "High" ? "High Mobility" : "Medium Mobility";

      const intent = ChatEngine.detectIntent(text);
      const detectedTopic = ChatEngine.detectTopic(text);
      this.lastQuestionType = intent;

      if (detectedTopic) {
        this.topicDepth = this.lastTopic === detectedTopic ? this.topicDepth + 1 : 1;
        this.lastTopic = detectedTopic;
      }

      this.conversationHistory.push({
        userInput: text,
        intent,
        topic: detectedTopic || this.lastTopic,
        timestamp: Date.now(),
      });

      const hasRun = !!this.state.lastRun;
      const metrics = hasRun
        ? {
            ...this.state.lastRun.metrics,
            pairs: this.state.pairs,
            agents: this.state.agents,
          }
        : null;

      const densityLevel = hasRun ? normalizeDensity(this.state.lastRun.densityLevel) : "Normal Density";
      const mobilityLevel = hasRun ? normalizeMobility(this.state.lastRun.mobilityLevel) : "Medium Mobility";
      const preferenceRule = hasRun ? this.state.lastRun.preferenceRule : "Attractiveness-based";

      return ChatEngine.buildChatReply(
        text,
        metrics,
        hasRun,
        densityLevel,
        mobilityLevel,
        preferenceRule,
        this.lastTopic,
        this.topicDepth
      );
    }

    resetTeachingExplanation() {
      this.teachingExplanation.textContent = this.getTeachingPlaceholderText();
      this.addChatMessage(
        "Assistant",
        "Ready to discuss results. Run the simulation or ask how mobility, density, and preference rules connect to Smaldino & Schank (2012)."
      );
      this.setExportEnabled(false);
      this.renderInsightQuestions();
    }

    setSimpleMode(enabled, options = {}) {
      const { announceInChat = false, refreshTeachingPanel = false } = options;
      this.simpleMode = !!enabled;

      if (this.chatSimpleToggle && this.chatSimpleToggle.checked !== this.simpleMode) {
        this.chatSimpleToggle.checked = this.simpleMode;
      }
      if (this.teachingSimpleToggle && this.teachingSimpleToggle.checked !== this.simpleMode) {
        this.teachingSimpleToggle.checked = this.simpleMode;
      }

      if (refreshTeachingPanel) {
        this.refreshTeachingPanelNarrative();
      }

      if (announceInChat) {
        this.addChatMessage(
          "Assistant",
          this.simpleMode
            ? "Simple mode on: I’ll explain runs in everyday language before citing the paper."
            : "Simple mode off: I’ll give fuller technical references."
        );
      }
    }

    getTeachingPlaceholderText() {
      return TeachingContent.getTeachingPlaceholderText(this.simpleMode);
    }

    buildTeachingPanelNarrative(
      metrics,
      mobilityLevel,
      densityLevel,
      preferenceRule,
      selectivityLevel,
      patienceLevel,
      explorationLevel
    ) {
      const normalizeDensity = (level) =>
        level === "Sparse" ? "Low Density" : level === "Dense" ? "High Density" : "Normal Density";
      const normalizeMobility = (level) =>
        level === "Low" ? "Low Mobility" : level === "High" ? "High Mobility" : "Medium Mobility";
      const moduleMetrics = {
        ...metrics,
        pairs: this.state.pairs,
        agents: this.state.agents,
      };

      return TeachingContent.buildTeachingPanelNarrative(
        moduleMetrics,
        normalizeMobility(mobilityLevel),
        normalizeDensity(densityLevel),
        preferenceRule,
        selectivityLevel,
        patienceLevel,
        explorationLevel,
        this.simpleMode
      );
    }

    refreshTeachingPanelNarrative() {
      if (!this.teachingExplanation) return;
      const lastRun = this.state && this.state.lastRun;
      if (!lastRun) {
        this.teachingExplanation.textContent = this.getTeachingPlaceholderText();
        return;
      }

      this.teachingExplanation.textContent = this.buildTeachingPanelNarrative(
        lastRun.metrics,
        lastRun.mobilityLevel,
        lastRun.densityLevel,
        lastRun.preferenceRule,
        lastRun.selectivityLevel,
        lastRun.patienceLevel,
        lastRun.explorationLevel
      );
    }

    updateTeachingExplanation() {
      const metrics = this.getSimulationMetrics();
      const preferenceRule = this.preferenceSelect.value;
      const mobilityLevel = this.mobilitySelect.value;
      const densityLevel = this.densitySelect.value;
      const selectivityLevel = this.selectivitySelect ? this.selectivitySelect.value : "Medium";
      const patienceLevel = this.patienceSelect ? this.patienceSelect.value : "Normal";
      const explorationLevel = this.explorationSelect ? this.explorationSelect.value : "Balanced";

      this.teachingExplanation.textContent = this.buildTeachingPanelNarrative(
        metrics,
        mobilityLevel,
        densityLevel,
        preferenceRule,
        selectivityLevel,
        patienceLevel,
        explorationLevel
      );
      this.appendRunSummary(metrics, mobilityLevel, densityLevel, preferenceRule);
      
      // Use simple mode or technical citation based on user preference
      const normalizeDensity = (level) =>
        level === "Sparse" ? "Low Density" : level === "Dense" ? "High Density" : "Normal Density";
      const normalizeMobility = (level) =>
        level === "Low" ? "Low Mobility" : level === "High" ? "High Mobility" : "Medium Mobility";
      const moduleMetrics = {
        ...metrics,
        pairs: this.state.pairs,
        agents: this.state.agents,
      };

      const chatMessage = this.simpleMode
        ? TeachingContent.buildSimpleExplainMessage(
            moduleMetrics,
            normalizeDensity(densityLevel),
            normalizeMobility(mobilityLevel),
            preferenceRule
          )
        : this.buildRunCitationMessage(
            moduleMetrics,
            normalizeMobility(mobilityLevel),
            normalizeDensity(densityLevel),
            preferenceRule,
            selectivityLevel,
            patienceLevel,
            explorationLevel
          );
      
      this.addChatMessage("Assistant", chatMessage);
      this.state.lastRun = {
        metrics,
        mobilityLevel,
        densityLevel,
        preferenceRule,
        selectivityLevel,
        patienceLevel,
        explorationLevel,
      };
      this.lastCitation = this.buildRunCitationMessage(
        moduleMetrics,
        normalizeMobility(mobilityLevel),
        normalizeDensity(densityLevel),
        preferenceRule,
        selectivityLevel,
        patienceLevel,
        explorationLevel
      );
      this.renderInsightQuestions();
      this.addChatMessage(
        "Assistant",
        "Try one of the insight questions below for this scenario."
      );
    }

    getSimulationMetrics() {
      const matchedAgents = this.state.agents.filter((agent) => agent.matched);
      const totalSearchSteps = this.state.agents.reduce((sum, agent) => sum + agent.searchSteps, 0);
      const averageSearchSteps = this.state.agents.length === 0
        ? 0
        : totalSearchSteps / this.state.agents.length;

      const pairDifferences = this.state.pairs.map((pair) => {
        const first = this.state.agents[pair.agent1];
        const second = this.state.agents[pair.agent2];
        return Math.abs(first.attractiveness - second.attractiveness);
      });

      const averageDifference = pairDifferences.length === 0
        ? 9
        : pairDifferences.reduce((sum, difference) => sum + difference, 0) / pairDifferences.length;

      const matchingStrength = this.clamp(1 - averageDifference / 9, 0, 1);

      return {
        pairCount: this.state.pairs.length,
        matchedCount: matchedAgents.length,
        averageSearchSteps,
        matchingStrength,
      };
    }

    appendRunSummary(metrics, mobilityLevel, densityLevel, preferenceRule) {
      const today = new Date().toISOString().slice(0, 10);
      const summary =
        " Simulation (" +
        today +
        ", " +
        densityLevel +
        ", " +
        mobilityLevel +
        ", " +
        preferenceRule +
        "): " +
        metrics.pairCount +
        " pairs, matching strength " +
        metrics.matchingStrength.toFixed(2) +
        ", avg search " +
        metrics.averageSearchSteps.toFixed(1) +
        ".";

      this.teachingExplanation.textContent += summary;
    }

    buildRunCitationMessage(metrics, mobilityLevel, densityLevel, preferenceRule, selectivityLevel, patienceLevel, explorationLevel) {
      const normalizeDensity = (level) =>
        level === "Sparse" ? "Low Density" : level === "Dense" ? "High Density" : "Normal Density";
      const normalizeMobility = (level) =>
        level === "Low" ? "Low Mobility" : level === "High" ? "High Mobility" : "Medium Mobility";
      const moduleMetrics = {
        ...metrics,
        pairs: this.state.pairs,
        agents: this.state.agents,
      };

      return TeachingContent.buildRunCitationMessage(
        moduleMetrics,
        normalizeMobility(mobilityLevel),
        normalizeDensity(densityLevel),
        preferenceRule,
        selectivityLevel,
        patienceLevel,
        explorationLevel
      );
    }

    setExportEnabled(isEnabled) {
      ExportEngine.setExportEnabled(isEnabled, {
        previewCsvButton: this.previewCsvButton,
        downloadCsvButton: this.downloadCsvButton,
        downloadPngButton: this.downloadPngButton,
        copyCitationButton: this.copyCitationButton,
      });
      
      if (isEnabled && this.state.lastRun) {
        this.lastCitation = this.buildRunCitationMessage(
          this.state.lastRun.metrics,
          this.state.lastRun.mobilityLevel,
          this.state.lastRun.densityLevel,
          this.state.lastRun.preferenceRule,
          this.state.lastRun.selectivityLevel,
          this.state.lastRun.patienceLevel,
          this.state.lastRun.explorationLevel
        );
      } else if (!isEnabled) {
        this.lastCitation = null;
      }
    }

    buildRunCsvText() {
      if (!this.state.lastRun) {
        return null;
      }

      const normalizeDensity = (level) =>
        level === "Sparse" ? "Low Density" : level === "Dense" ? "High Density" : "Normal Density";
      const normalizeMobility = (level) =>
        level === "Low" ? "Low Mobility" : level === "High" ? "High Mobility" : "Medium Mobility";

      const exportMetrics = {
        pairs: this.state.pairs.map((pair) => ({ a: pair.agent1, b: pair.agent2 })),
        agents: this.state.agents.map((agent) => ({ id: agent.id, attr: agent.attractiveness })),
        matchingStrength: this.state.lastRun.metrics.matchingStrength,
        averageSearchSteps: this.state.lastRun.metrics.averageSearchSteps,
        matchedAgents: this.state.lastRun.metrics.matchedCount,
      };

      const exportSettings = {
        mobilityLevel: normalizeMobility(this.state.lastRun.mobilityLevel),
        densityLevel: normalizeDensity(this.state.lastRun.densityLevel),
        preferenceRule: this.state.lastRun.preferenceRule,
        selectivityLevel: this.state.lastRun.selectivityLevel || "Medium",
        patienceLevel: this.state.lastRun.patienceLevel || "Normal",
        explorationLevel: this.state.lastRun.explorationLevel || "Balanced",
      };

      return ExportEngine.buildRunCsvText(exportMetrics, exportSettings);
    }

    previewCsv() {
      const csv = this.buildRunCsvText();
      if (!csv) {
        this.addChatMessage("Assistant", "Run first, then preview the summary.");
        return;
      }
      this.showCsvPreview(csv);
    }

    downloadCsv() {
      if (!this.state.lastRun) {
        this.addChatMessage("Assistant", "Run first, then download the summary.");
        return;
      }

      const normalizeDensity = (level) =>
        level === "Sparse" ? "Low Density" : level === "Dense" ? "High Density" : "Normal Density";
      const normalizeMobility = (level) =>
        level === "Low" ? "Low Mobility" : level === "High" ? "High Mobility" : "Medium Mobility";

      const exportMetrics = {
        pairs: this.state.pairs.map((pair) => ({ a: pair.agent1, b: pair.agent2 })),
        agents: this.state.agents.map((agent) => ({ id: agent.id, attr: agent.attractiveness })),
        matchingStrength: this.state.lastRun.metrics.matchingStrength,
        averageSearchSteps: this.state.lastRun.metrics.averageSearchSteps,
        matchedAgents: this.state.lastRun.metrics.matchedCount,
      };

      const exportSettings = {
        mobilityLevel: normalizeMobility(this.state.lastRun.mobilityLevel),
        densityLevel: normalizeDensity(this.state.lastRun.densityLevel),
        preferenceRule: this.state.lastRun.preferenceRule,
        selectivityLevel: this.state.lastRun.selectivityLevel || "Medium",
        patienceLevel: this.state.lastRun.patienceLevel || "Normal",
        explorationLevel: this.state.lastRun.explorationLevel || "Balanced",
      };

      ExportEngine.downloadCsv(exportMetrics, exportSettings);
    }

    showCsvPreview(csvText) {
      if (!this.csvPreview || !this.csvPreviewContent) return;
      const reportData = this.buildPreviewReportData();
      if (!reportData) {
        this.addChatMessage("Assistant", "Run first, then preview the summary.");
        return;
      }

      this.csvPreviewContent.textContent = csvText;
      this.csvPreview.classList.add("is-visible");
      this.populatePreviewNarrative(reportData);
      RenderEngine.drawPreviewMetricsChart(this.previewMetricsChart, reportData, STEP_COUNT);
      RenderEngine.drawPreviewDifferenceChart(this.previewDifferenceChart, reportData.pairDifferenceBins);
      this.populateChartInsights(reportData);
      this.populateRuleAnalytics(reportData);
    }

    buildPreviewReportData() {
      if (!this.state.lastRun) return null;

      const { metrics, mobilityLevel, densityLevel, preferenceRule, selectivityLevel, patienceLevel, explorationLevel } = this.state.lastRun;
      const totalAgents = this.state.agents.length || 0;
      const maxPairs = Math.max(1, Math.floor(totalAgents / 2));

      const pairDifferenceBins = new Array(10).fill(0);
      this.state.pairs.forEach((pair) => {
        const first = this.state.agents[pair.agent1];
        const second = this.state.agents[pair.agent2];
        if (!first || !second) return;
        const diff = Math.abs(first.attractiveness - second.attractiveness);
        pairDifferenceBins[diff] += 1;
      });

      const structureLabel =
        metrics.matchingStrength >= 0.35
          ? "highly sorted"
          : metrics.matchingStrength >= 0.2
          ? "moderately sorted"
          : "weakly sorted";

      return {
        metrics,
        mobilityLevel,
        densityLevel,
        preferenceRule,
        selectivityLevel: selectivityLevel || "Medium",
        patienceLevel: patienceLevel || "Normal",
        explorationLevel: explorationLevel || "Balanced",
        totalAgents,
        maxPairs,
        pairDifferenceBins,
        structureLabel,
      };
    }

    populatePreviewNarrative(reportData) {
      const {
        metrics,
        mobilityLevel,
        densityLevel,
        preferenceRule,
        selectivityLevel,
        patienceLevel,
        explorationLevel,
        structureLabel,
      } = reportData;

      if (this.previewKpiPairs) {
        this.previewKpiPairs.textContent = String(metrics.pairCount);
      }
      if (this.previewKpiStrength) {
        this.previewKpiStrength.textContent = metrics.matchingStrength.toFixed(2);
      }
      if (this.previewKpiSearch) {
        this.previewKpiSearch.textContent = metrics.averageSearchSteps.toFixed(1);
      }

      if (this.previewIntroText) {
        this.previewIntroText.textContent =
          "This run evaluated " +
          preferenceRule.toLowerCase() +
          " matching under " +
          densityLevel.toLowerCase() +
          " density and " +
          mobilityLevel.toLowerCase() +
          " mobility, with selectivity " +
          selectivityLevel.toLowerCase() +
          ", patience " +
          patienceLevel.toLowerCase() +
          ", and exploration " +
          explorationLevel.toLowerCase() +
          ".";
      }

      if (this.previewBodyText) {
        this.previewBodyText.textContent =
          "The simulation produced " +
          metrics.pairCount +
          " pairs and a matching strength of " +
          metrics.matchingStrength.toFixed(2) +
          ", indicating a " +
          structureLabel +
          " pairing pattern. Average search steps reached " +
          metrics.averageSearchSteps.toFixed(1) +
          ", which reflects how quickly agents found acceptable partners under these constraints.";
      }

      if (this.previewConclusionText) {
        const searchEfficiency =
          metrics.averageSearchSteps > 20
            ? "search was slow"
            : metrics.averageSearchSteps > 12
            ? "search was moderate"
            : "search was fast";

        const pairingResult =
          metrics.pairCount === 0
            ? "no stable pairs formed"
            : metrics.pairCount < Math.max(3, Math.floor(reportData.maxPairs * 0.35))
            ? "pair formation remained limited"
            : "pair formation was substantial";

        this.previewConclusionText.textContent =
          "Conclusion: Under " +
          reportData.densityLevel.toLowerCase() +
          " density, " +
          reportData.mobilityLevel.toLowerCase() +
          " mobility, and the " +
          reportData.preferenceRule.toLowerCase() +
          " rule, this run produced " +
          metrics.pairCount +
          " pairs with matching strength " +
          metrics.matchingStrength.toFixed(2) +
          ". Overall, the system was " +
          structureLabel +
          ": " +
          pairingResult +
          " and " +
          searchEfficiency +
          " (avg search " +
          metrics.averageSearchSteps.toFixed(1) +
          " steps). Use the hazard explorer to see which rule/movement combinations accelerate early matching, and use the pair-difference distribution to judge whether similarity came from strong preference filtering or local encounter constraints.";
      }
    }

    populateChartInsights(reportData) {
      const { metrics, maxPairs, pairDifferenceBins, structureLabel } = reportData;
      const pairRate = maxPairs > 0 ? (metrics.pairCount / maxPairs) * 100 : 0;
      const searchPercent = (Math.min(STEP_COUNT, metrics.averageSearchSteps) / STEP_COUNT) * 100;

      if (this.previewMetricsInsight) {
        this.previewMetricsInsight.textContent =
          "Insight: Pairs reached " +
          pairRate.toFixed(0) +
          "% of the maximum possible count, matching strength is " +
          metrics.matchingStrength.toFixed(2) +
          " (" +
          structureLabel +
          "), and average search used " +
          searchPercent.toFixed(0) +
          "% of the run horizon. Higher search with lower pair/strength bars usually indicates tighter encounter constraints.";
      }

      if (this.previewDifferenceInsight) {
        if (metrics.pairCount === 0) {
          this.previewDifferenceInsight.textContent =
            "Insight: No pairs formed in this run, so the distribution has no partner-difference data yet.";
          return;
        }

        const lowDifferenceCount = pairDifferenceBins[0] + pairDifferenceBins[1] + pairDifferenceBins[2];
        const lowDifferenceShare = (lowDifferenceCount / metrics.pairCount) * 100;
        let peakBin = 0;
        for (let i = 1; i < pairDifferenceBins.length; i += 1) {
          if (pairDifferenceBins[i] > pairDifferenceBins[peakBin]) {
            peakBin = i;
          }
        }

        this.previewDifferenceInsight.textContent =
          "Insight: " +
          lowDifferenceShare.toFixed(0) +
          "% of pairs are in low-difference bins (0-2), and the peak bin is difference " +
          peakBin +
          ". More mass in lower bins means partners were more similar; heavier right-side bins indicate weaker assortment.";
      }
    }

    populateRuleAnalytics(reportData) {
      if (!this.ruleAnalyticsBody || !this.ruleHazardChart || !this.ruleHazardInsight) return;

      const settings = {
        densityLevel: reportData.densityLevel,
        mobilityLevel: reportData.mobilityLevel,
        selectivityLevel: reportData.selectivityLevel,
        patienceLevel: reportData.patienceLevel,
      };

      const analyticsRows = this.computeRuleAnalyticsRows(settings, RULE_ANALYTICS_RUNS);
      this.lastRuleAnalyticsRows = analyticsRows;
      this.renderHazardSeriesToggles(analyticsRows);
      this.updateRuleCodeExplainer(analyticsRows);

      this.renderRuleAnalyticsTable(analyticsRows);
      this.drawRuleHazardChart(analyticsRows);
      this.drawRuleHazardZoomChart(analyticsRows, 15);
      if (this.recreatedFigure5Chart) {
        RenderEngine.drawRecreatedGroupedFigure(
          this.recreatedFigure5Chart,
          analyticsRows,
          "interPairCorrelation",
          "interPairCorrelationReplacement",
          "Inter-pair correlation"
        );
      }
      if (this.recreatedFigure6Chart) {
        RenderEngine.drawRecreatedGroupedFigure(
          this.recreatedFigure6Chart,
          analyticsRows,
          "meanDateToMate",
          "meanDateToMateReplacement",
          "Mean date to mate"
        );
      }
      if (this.recreatedFigure7Chart) {
        RenderEngine.drawRecreatedFigure7(this.recreatedFigure7Chart, analyticsRows);
      }
      this.updateRecreatedFigureInsights(analyticsRows);
    }

    updateRecreatedFigureInsights(rows) {
      if (!rows || !rows.length) return;

      if (this.recreatedFigure5Insight) {
        this.recreatedFigure5Insight.textContent = AnalyticsEngine.generateFigure5Insight(rows);
      }

      if (this.recreatedFigure6Insight) {
        this.recreatedFigure6Insight.textContent = AnalyticsEngine.generateFigure6Insight(rows);
      }

      if (this.recreatedFigure7Insight) {
        this.recreatedFigure7Insight.textContent = AnalyticsEngine.generateFigure7Insight(rows);
      }
    }

    computeRuleAnalyticsRows(settings, runCount) {
      const combinations = [
        { ruleLabel: "Rule 1", ruleShort: "R1", preferenceRule: "Attractiveness-based", movement: "NS", explorationLevel: "Local" },
        { ruleLabel: "Rule 1", ruleShort: "R1", preferenceRule: "Attractiveness-based", movement: "ZZ", explorationLevel: "Balanced" },
        { ruleLabel: "Rule 1", ruleShort: "R1", preferenceRule: "Attractiveness-based", movement: "BR", explorationLevel: "Wide" },
        { ruleLabel: "Rule 2", ruleShort: "R2", preferenceRule: "Similarity-based", movement: "NS", explorationLevel: "Local" },
        { ruleLabel: "Rule 2", ruleShort: "R2", preferenceRule: "Similarity-based", movement: "ZZ", explorationLevel: "Balanced" },
        { ruleLabel: "Rule 2", ruleShort: "R2", preferenceRule: "Similarity-based", movement: "BR", explorationLevel: "Wide" },
      ];

      return combinations.map((combo) => {
        const pairCorrValues = [];
        const meanDateValues = [];
        const meanHazardValues = [];
        const pairCorrReplacementValues = [];
        const meanDateReplacementValues = [];
        const hazardSum = new Array(STEP_COUNT).fill(0);

        for (let runIndex = 0; runIndex < runCount; runIndex += 1) {
          const result = this.runSyntheticSimulation({
            preferenceRule: combo.preferenceRule,
            movementLevel: combo.explorationLevel,
            densityLevel: settings.densityLevel,
            mobilityLevel: settings.mobilityLevel,
            selectivityLevel: settings.selectivityLevel,
            patienceLevel: settings.patienceLevel,
          });
          const replacementResult = this.runSyntheticSimulation({
            preferenceRule: combo.preferenceRule,
            movementLevel: combo.explorationLevel,
            densityLevel: settings.densityLevel,
            mobilityLevel: settings.mobilityLevel,
            selectivityLevel: settings.selectivityLevel,
            patienceLevel: settings.patienceLevel,
            withReplacement: true,
          });

          pairCorrValues.push(result.interPairCorrelation);
          meanDateValues.push(result.meanDateToMate);
          meanHazardValues.push(result.meanHazard);
          pairCorrReplacementValues.push(replacementResult.interPairCorrelation);
          meanDateReplacementValues.push(replacementResult.meanDateToMate);
          result.hazardSeries.forEach((value, index) => {
            hazardSum[index] += value;
          });
        }

        const corrStats = this.computeBatchStats(pairCorrValues);
        const dateStats = this.computeBatchStats(meanDateValues);
        const hazardStats = this.computeBatchStats(meanHazardValues);
        const corrReplacementStats = this.computeBatchStats(pairCorrReplacementValues);
        const dateReplacementStats = this.computeBatchStats(meanDateReplacementValues);

        return {
          ...combo,
          interPairCorrelation: corrStats.mean,
          interPairCorrelationCiLow: corrStats.ciLow,
          interPairCorrelationCiHigh: corrStats.ciHigh,
          meanDateToMate: dateStats.mean,
          meanDateToMateCiLow: dateStats.ciLow,
          meanDateToMateCiHigh: dateStats.ciHigh,
          meanHazard: hazardStats.mean,
          meanHazardCiLow: hazardStats.ciLow,
          meanHazardCiHigh: hazardStats.ciHigh,
          interPairCorrelationReplacement: corrReplacementStats.mean,
          meanDateToMateReplacement: dateReplacementStats.mean,
          hazardSeries: hazardSum.map((value) => value / runCount),
        };
      });
    }

    runSyntheticSimulation(settings) {
      const size = this.getCanvasSize();
      const padding = AGENT_RADIUS + 2;
      const densityMultiplier = densityMultipliers[settings.densityLevel] || 1;
      const agentCount = Math.max(10, Math.round(size * size * baseDensityFactor * densityMultiplier));

      const agents = [];
      const pairs = [];
      const matchedEventSteps = [];
      const matchedPairValues = [];
      for (let i = 0; i < agentCount; i += 1) {
        agents.push(this.createSyntheticAgent(i, size, padding));
      }

      const movement = (mobilitySizes[settings.mobilityLevel] || mobilitySizes.Medium) *
        (explorationMultipliers[settings.movementLevel] || explorationMultipliers.Balanced);

      for (let step = 1; step <= STEP_COUNT; step += 1) {
        agents.forEach((agent) => {
          if (agent.matched) return;
          agent.x = this.clamp(agent.x + this.randomFloat(-movement, movement), padding, size - padding);
          agent.y = this.clamp(agent.y + this.randomFloat(-movement, movement), padding, size - padding);
        });

        const unmatched = this.shuffle(agents.filter((agent) => !agent.matched));
        for (let i = 0; i < unmatched.length; i += 1) {
          const first = unmatched[i];
          if (first.matched) continue;

          for (let j = i + 1; j < unmatched.length; j += 1) {
            const second = unmatched[j];
            if (second.matched) continue;
            if (this.getDistance(first, second) > ENCOUNTER_DISTANCE) continue;

            const acceptFirst = this.getAcceptanceScoreWithSettings(
              first,
              second,
              settings.preferenceRule,
              settings.selectivityLevel,
              settings.patienceLevel
            );
            const acceptSecond = this.getAcceptanceScoreWithSettings(
              second,
              first,
              settings.preferenceRule,
              settings.selectivityLevel,
              settings.patienceLevel
            );

            if (Math.random() < acceptFirst && Math.random() < acceptSecond) {
              matchedPairValues.push([first.attractiveness, second.attractiveness]);
              matchedEventSteps.push(step, step);

              if (settings.withReplacement) {
                first.matched = true;
                second.matched = true;
                agents[first.id] = this.createSyntheticAgent(first.id, size, padding);
                agents[second.id] = this.createSyntheticAgent(second.id, size, padding);
                break;
              }

              first.matched = true;
              second.matched = true;
              first.partnerId = second.id;
              second.partnerId = first.id;
              first.matchedAtStep = step;
              second.matchedAtStep = step;
              pairs.push({ agent1: first.id, agent2: second.id });
              break;
            }
          }
        }

        agents.forEach((agent) => {
          if (!agent.matched) agent.searchSteps += 1;
        });
      }

      const interPairCorrelation = settings.withReplacement
        ? this.computeInterPairCorrelationFromPairs(matchedPairValues)
        : this.computeInterPairCorrelation(agents, pairs);
      const meanDateToMate = matchedEventSteps.length
        ? matchedEventSteps.reduce((sum, value) => sum + value, 0) / matchedEventSteps.length
        : STEP_COUNT;
      const hazardSeries = settings.withReplacement
        ? this.computeHazardSeriesFromEvents(matchedEventSteps, agentCount)
        : this.computeHazardSeries(agents);
      const meanHazard = hazardSeries.reduce((sum, value) => sum + value, 0) / hazardSeries.length;

      return {
        interPairCorrelation,
        meanDateToMate,
        meanHazard,
        hazardSeries,
      };
    }

    createSyntheticAgent(id, size, padding) {
      return {
        id,
        attractiveness: this.randomInt(1, 10),
        x: this.randomFloat(padding, size - padding),
        y: this.randomFloat(padding, size - padding),
        matched: false,
        partnerId: null,
        matchedAtStep: null,
        searchSteps: 0,
      };
    }

    getAcceptanceScoreWithSettings(agent, candidate, preferenceRule, selectivityLevel, patienceLevel) {
      const selectivity = selectivityMultipliers[selectivityLevel || "Medium"] || 1;
      const patienceRate = patienceRates[patienceLevel || "Normal"] || 0.01;
      const patienceBoost = agent.searchSteps * patienceRate;

      if (preferenceRule === "Similarity-based") {
        const difference = Math.abs(agent.attractiveness - candidate.attractiveness);
        return this.clamp((1 - difference / 9) * selectivity + patienceBoost, 0.1, 1);
      }

      return this.clamp((candidate.attractiveness / 10) * selectivity + patienceBoost, 0.1, 1);
    }

    computeInterPairCorrelation(agents, pairs) {
      if (!pairs.length) return 0;

      const xs = [];
      const ys = [];
      pairs.forEach((pair) => {
        const first = agents[pair.agent1];
        const second = agents[pair.agent2];
        if (!first || !second) return;
        xs.push(first.attractiveness);
        ys.push(second.attractiveness);
      });

      if (xs.length < 2) return 0;

      const n = xs.length;
      const sumX = xs.reduce((sum, value) => sum + value, 0);
      const sumY = ys.reduce((sum, value) => sum + value, 0);
      const sumXX = xs.reduce((sum, value) => sum + value * value, 0);
      const sumYY = ys.reduce((sum, value) => sum + value * value, 0);
      const sumXY = xs.reduce((sum, value, index) => sum + value * ys[index], 0);

      const numerator = n * sumXY - sumX * sumY;
      const denomX = n * sumXX - sumX * sumX;
      const denomY = n * sumYY - sumY * sumY;
      const denominator = Math.sqrt(Math.max(denomX, 0) * Math.max(denomY, 0));

      if (!denominator) return 0;
      return this.clamp(numerator / denominator, -1, 1);
    }

    computeInterPairCorrelationFromPairs(pairValues) {
      if (!pairValues.length) return 0;
      const xs = pairValues.map((pair) => pair[0]);
      const ys = pairValues.map((pair) => pair[1]);
      if (xs.length < 2) return 0;

      const n = xs.length;
      const sumX = xs.reduce((sum, value) => sum + value, 0);
      const sumY = ys.reduce((sum, value) => sum + value, 0);
      const sumXX = xs.reduce((sum, value) => sum + value * value, 0);
      const sumYY = ys.reduce((sum, value) => sum + value * value, 0);
      const sumXY = xs.reduce((sum, value, index) => sum + value * ys[index], 0);

      const numerator = n * sumXY - sumX * sumY;
      const denomX = n * sumXX - sumX * sumX;
      const denomY = n * sumYY - sumY * sumY;
      const denominator = Math.sqrt(Math.max(denomX, 0) * Math.max(denomY, 0));
      if (!denominator) return 0;
      return this.clamp(numerator / denominator, -1, 1);
    }

    computeHazardSeries(agents) {
      const series = [];
      let atRisk = agents.length;

      for (let step = 1; step <= STEP_COUNT; step += 1) {
        if (atRisk <= 0) {
          series.push(0);
          continue;
        }

        const events = agents.filter((agent) => agent.matchedAtStep === step).length;
        const hazard = events / atRisk;
        series.push(hazard);
        atRisk -= events;
      }

      return series;
    }

    computeHazardSeriesFromEvents(matchedEventSteps, atRiskCount) {
      const series = [];
      for (let step = 1; step <= STEP_COUNT; step += 1) {
        const events = matchedEventSteps.filter((value) => value === step).length;
        series.push(atRiskCount > 0 ? events / atRiskCount : 0);
      }
      return series;
    }

    renderRuleAnalyticsTable(rows) {
      if (!this.ruleAnalyticsBody) return;
      this.ruleAnalyticsBody.innerHTML = rows
        .map((row) => {
          const corrCiClass = this.getCiClass("correlation", row.interPairCorrelationCiLow, row.interPairCorrelationCiHigh);
          const dateCiClass = this.getCiClass("date", row.meanDateToMateCiLow, row.meanDateToMateCiHigh);
          const hazardCiClass = this.getCiClass("hazard", row.meanHazardCiLow, row.meanHazardCiHigh);

          return (
            "<tr><td>" +
            row.ruleLabel +
            "</td><td>" +
            row.movement +
            "</td><td class=\"" +
            corrCiClass +
            "\">" +
            row.interPairCorrelation.toFixed(3) +
            " [" +
            row.interPairCorrelationCiLow.toFixed(3) +
            ", " +
            row.interPairCorrelationCiHigh.toFixed(3) +
            "]" +
            "</td><td class=\"" +
            dateCiClass +
            "\">" +
            row.meanDateToMate.toFixed(2) +
            " [" +
            row.meanDateToMateCiLow.toFixed(2) +
            ", " +
            row.meanDateToMateCiHigh.toFixed(2) +
            "]" +
            "</td><td class=\"" +
            hazardCiClass +
            "\">" +
            row.meanHazard.toFixed(3) +
            " [" +
            row.meanHazardCiLow.toFixed(3) +
            ", " +
            row.meanHazardCiHigh.toFixed(3) +
            "]" +
            "</td></tr>"
          );
        })
        .join("");

      if (this.ruleAnalyticsDefinitions) {
        this.ruleAnalyticsDefinitions.textContent =
          "Statistics: each row reports mean with 95% CI from n=" +
          RULE_ANALYTICS_RUNS +
          " synthetic runs. CI colors: green=tight, amber=medium, rose=wide.";
      }
    }

    getCiClass(metricType, ciLow, ciHigh) {
      const width = Math.max(0, ciHigh - ciLow);

      if (metricType === "correlation") {
        if (width <= 0.10) return "ci-tight";
        if (width <= 0.20) return "ci-medium";
        return "ci-wide";
      }

      if (metricType === "date") {
        if (width <= 6) return "ci-tight";
        if (width <= 12) return "ci-medium";
        return "ci-wide";
      }

      if (metricType === "hazard") {
        if (width <= 0.05) return "ci-tight";
        if (width <= 0.12) return "ci-medium";
        return "ci-wide";
      }

      return "";
    }

    drawRuleHazardChart(rows) {
      if (!this.ruleHazardChart) return;

      const visibleRows = AnalyticsEngine.getVisibleHazardRows(rows, this.hazardSeriesSelection);
      if (!visibleRows.length) {
        RenderEngine.drawNoDataChartMessage(this.ruleHazardChart, "No series selected. Use toggles to add rules.", 260);
        this.ruleHazardHoverData = null;
        this.updateHazardDynamicExplainer([], this.getHazardChartMode());
        return;
      }
      const mode = this.getHazardChartMode();

      const chartRows = visibleRows.map((row) => ({
        label: row.ruleShort + "-" + row.movement,
        values: AnalyticsEngine.getHazardDisplayValues(row.hazardSeries, mode),
      }));

      this.ruleHazardHoverData = RenderEngine.drawHazardChart(this.ruleHazardChart, chartRows, {
        maxStep: STEP_COUNT,
        mode,
        canvasHeight: 260,
        showLegend: true,
        lineWidth: 2.6,
      });

      let peakRow = rows[0];
      visibleRows.forEach((row) => {
        if (Math.max(...row.hazardSeries) > Math.max(...peakRow.hazardSeries)) {
          peakRow = row;
        }
      });

      if (this.ruleHazardInsight) {
        this.ruleHazardInsight.textContent =
          "Insight: Hazard at step t is h(t)=matches(t)/atRisk(t). The highest peak hazard in this benchmark appears under " +
          peakRow.ruleLabel +
          " " +
          peakRow.movement +
          ", meaning that combination yields the fastest early conversion from unmatched to matched states. See the zoom chart for readable early-step separation.";
      }
      this.updateHazardDynamicExplainer(visibleRows, mode);
    }

    drawRuleHazardZoomChart(rows, maxStep) {
      if (!this.ruleHazardZoomChart) return;

      const visibleRows = AnalyticsEngine.getVisibleHazardRows(rows, this.hazardSeriesSelection);
      if (!visibleRows.length) {
        RenderEngine.drawNoDataChartMessage(this.ruleHazardZoomChart, "No series selected. Use toggles to add rules.", 260);
        this.ruleHazardZoomHoverData = null;
        return;
      }
      const mode = this.getHazardChartMode();

      const chartRows = visibleRows.map((row) => ({
        label: row.ruleShort + "-" + row.movement,
        values: AnalyticsEngine.getHazardDisplayValues(row.hazardSeries, mode).slice(0, maxStep),
      }));

      this.ruleHazardZoomHoverData = RenderEngine.drawHazardChart(this.ruleHazardZoomChart, chartRows, {
        maxStep,
        mode,
        canvasHeight: 260,
        showLegend: false,
        lineWidth: 2.8,
      });
    }

    bindHazardExplorerEvents() {
      if (this.hazardChartMode) {
        this.hazardChartMode.addEventListener("change", () => this.redrawHazardExplorer());
      }
      if (this.hazardSelectAllButton) {
        this.hazardSelectAllButton.addEventListener("click", () => {
          if (!this.lastRuleAnalyticsRows) return;
          this.disableAutoTop2IfNeeded();
          UIController.setAllHazardSelections(this.lastRuleAnalyticsRows, this.hazardSeriesSelection, true);
          this.renderHazardSeriesToggles(this.lastRuleAnalyticsRows);
          this.redrawHazardExplorer();
        });
      }
      if (this.hazardClearAllButton) {
        this.hazardClearAllButton.addEventListener("click", () => {
          if (!this.lastRuleAnalyticsRows) return;
          this.disableAutoTop2IfNeeded();
          UIController.setAllHazardSelections(this.lastRuleAnalyticsRows, this.hazardSeriesSelection, false);
          this.renderHazardSeriesToggles(this.lastRuleAnalyticsRows);
          this.redrawHazardExplorer();
        });
      }
      if (this.hazardAutoTop2) {
        this.hazardAutoTop2.addEventListener("change", () => {
          this.autoHighlightTop2Enabled = !!this.hazardAutoTop2.checked;
          this.redrawHazardExplorer();
        });
      }
      if (this.hazardAutoTopN) {
        this.hazardAutoTopN.addEventListener("change", () => {
          if (!this.autoHighlightTop2Enabled) return;
          this.redrawHazardExplorer();
        });
      }
    }

    redrawHazardExplorer() {
      if (!this.lastRuleAnalyticsRows) return;
      if (this.autoHighlightTop2Enabled) {
        this.applyAutoHighlightTop2(this.lastRuleAnalyticsRows);
      } else {
        this.autoHighlightedSeriesLabels = [];
      }
      this.renderHazardSeriesToggles(this.lastRuleAnalyticsRows);
      this.updateRuleCodeExplainer(this.lastRuleAnalyticsRows);
      this.drawRuleHazardChart(this.lastRuleAnalyticsRows);
      this.drawRuleHazardZoomChart(this.lastRuleAnalyticsRows, 15);
    }

    renderHazardSeriesToggles(rows) {
      UIController.renderHazardSeriesToggles(
        this.hazardSeriesToggles,
        rows,
        this.hazardSeriesSelection,
        this.autoHighlightedSeriesLabels,
        (label, checked) => {
          this.disableAutoTop2IfNeeded();
          this.hazardSeriesSelection[label] = checked;
          this.redrawHazardExplorer();
        }
      );
    }

    disableAutoTop2IfNeeded() {
      if (!this.autoHighlightTop2Enabled) return;
      this.autoHighlightTop2Enabled = false;
      if (this.hazardAutoTop2) {
        this.hazardAutoTop2.checked = false;
      }
    }

    applyAutoHighlightTop2(rows) {
      const selectedCount = this.getAutoHighlightCount();
      const top2 = AnalyticsEngine.getMostDivergentLabels(rows, this.getHazardChartMode(), 15, selectedCount);
      this.lastRuleAnalyticsRows.forEach((row) => {
        const label = row.ruleShort + "-" + row.movement;
        this.hazardSeriesSelection[label] = top2.includes(label);
      });
      this.autoHighlightedSeriesLabels = [...top2];
    }

    getAutoHighlightCount() {
      const parsed = parseInt(this.hazardAutoTopN ? this.hazardAutoTopN.value : "2", 10);
      return this.clamp(parsed || 2, 2, 4);
    }

    getHazardChartMode() {
      return this.hazardChartMode ? this.hazardChartMode.value : "line";
    }

    updateHazardDynamicExplainer(visibleRows, mode) {
      if (!this.hazardDynamicExplainer) return;
      this.hazardDynamicExplainer.textContent =
        AnalyticsEngine.buildHazardDynamicExplainer(
          visibleRows,
          mode,
          this.autoHighlightTop2Enabled,
          this.getAutoHighlightCount()
        );
    }

    updateRuleCodeExplainer(rows) {
      if (!this.ruleCodeExplainer) return;
      const selected = AnalyticsEngine.getSelectedHazardLabels(rows, this.hazardSeriesSelection);
      const selectedText = selected.length ? selected.join(", ") : "none selected";
      this.ruleCodeExplainer.textContent =
        "Selected now: " +
        selectedText +
        ".";
    }

    bindHazardTooltipEvents() {
      if (this.ruleHazardChart && this.ruleHazardTooltip) {
        this.ruleHazardChart.addEventListener("mousemove", (event) =>
          this.handleHazardTooltipMove(event, this.ruleHazardChart, this.ruleHazardTooltip, () => this.ruleHazardHoverData)
        );
        this.ruleHazardChart.addEventListener("mouseleave", () => this.hideHazardTooltip(this.ruleHazardTooltip));
      }

      if (this.ruleHazardZoomChart && this.ruleHazardZoomTooltip) {
        this.ruleHazardZoomChart.addEventListener("mousemove", (event) =>
          this.handleHazardTooltipMove(event, this.ruleHazardZoomChart, this.ruleHazardZoomTooltip, () => this.ruleHazardZoomHoverData)
        );
        this.ruleHazardZoomChart.addEventListener("mouseleave", () => this.hideHazardTooltip(this.ruleHazardZoomTooltip));
      }
    }

    handleHazardTooltipMove(event, canvas, tooltip, hoverDataGetter) {
      const hoverData = hoverDataGetter();
      if (!hoverData) return;

      const rect = canvas.getBoundingClientRect();
      const localX = event.clientX - rect.left;
      const clampedX = this.clamp(localX, hoverData.left, hoverData.right);
      const relative = (clampedX - hoverData.left) / Math.max(1, hoverData.chartWidth);
      const stepIndex = this.clamp(Math.round(relative * (hoverData.maxStep - 1)), 0, hoverData.maxStep - 1);

      const lines = ["Step " + (stepIndex + 1)];
      hoverData.series.forEach((series) => {
        const value = series.values[stepIndex] || 0;
        lines.push(
          '<span style="color:' +
            series.color +
            ';font-weight:700;">' +
            series.label +
            "</span>: " +
            value.toFixed(3)
        );
      });
      tooltip.innerHTML = lines.join("<br>");

      const parentRect = canvas.parentElement ? canvas.parentElement.getBoundingClientRect() : rect;
      const tooltipX = event.clientX - parentRect.left + 12;
      const tooltipY = event.clientY - parentRect.top - 8;
      tooltip.style.left = Math.min(tooltipX, parentRect.width - 240) + "px";
      tooltip.style.top = Math.max(tooltipY, 24) + "px";
      tooltip.classList.add("is-visible");
    }

    hideHazardTooltip(tooltip) {
      if (!tooltip) return;
      tooltip.classList.remove("is-visible");
    }

    resetPreviewContent() {
      if (this.csvPreviewContent) {
        this.csvPreviewContent.textContent = "";
      }
      if (this.previewIntroText) {
        this.previewIntroText.textContent =
          "Run a simulation, then use Preview run summary (CSV) to generate an interpreted report.";
      }
      if (this.previewBodyText) {
        this.previewBodyText.textContent =
          "This section summarizes how your control settings interacted with observed outcomes.";
      }
      if (this.previewConclusionText) {
        this.previewConclusionText.textContent =
          "The conclusion synthesizes what this run suggests about encounter constraints and matching patterns.";
      }
      if (this.previewKpiPairs) this.previewKpiPairs.textContent = "-";
      if (this.previewKpiStrength) this.previewKpiStrength.textContent = "-";
      if (this.previewKpiSearch) this.previewKpiSearch.textContent = "-";
      if (this.previewMetricsInsight) {
        this.previewMetricsInsight.textContent =
          "Insight: This chart compares run-level outcomes where taller bars indicate stronger values.";
      }
      if (this.previewDifferenceInsight) {
        this.previewDifferenceInsight.textContent =
          "Insight: This chart shows how similar partners were, with lower difference bins indicating stronger assortative matching.";
      }
      if (this.ruleAnalyticsDefinitions) {
        this.ruleAnalyticsDefinitions.textContent =
          "Statistics: each row reports mean with 95% CI from n=" +
          RULE_ANALYTICS_RUNS +
          " synthetic runs. CI colors: green=tight, amber=medium, rose=wide.";
      }
      if (this.ruleCodeExplainer) {
        this.ruleCodeExplainer.textContent = "Selected now: none selected.";
      }
      if (this.ruleAnalyticsBody) {
        this.ruleAnalyticsBody.innerHTML = "<tr><td colspan=\"5\">Run preview to compute analytics.</td></tr>";
      }
      if (this.ruleHazardInsight) {
        this.ruleHazardInsight.textContent =
          "Insight: Hazard at step t is matches at t divided by agents still unmatched at the start of t.";
      }
      if (this.ruleHazardChart) {
        const ruleCtx = this.ruleHazardChart.getContext("2d");
        if (ruleCtx) {
          const chartSize = RenderEngine.prepareHiDPICanvas(this.ruleHazardChart, 260);
          ruleCtx.clearRect(0, 0, chartSize.width, chartSize.height);
        }
      }
      if (this.ruleHazardZoomChart) {
        const zoomCtx = this.ruleHazardZoomChart.getContext("2d");
        if (zoomCtx) {
          const chartSize = RenderEngine.prepareHiDPICanvas(this.ruleHazardZoomChart, 260);
          zoomCtx.clearRect(0, 0, chartSize.width, chartSize.height);
        }
      }
      this.ruleHazardHoverData = null;
      this.ruleHazardZoomHoverData = null;
      this.hideHazardTooltip(this.ruleHazardTooltip);
      this.hideHazardTooltip(this.ruleHazardZoomTooltip);
      [this.recreatedFigure5Chart, this.recreatedFigure6Chart, this.recreatedFigure7Chart].forEach((canvas) => {
        if (!canvas) return;
        const ctx = canvas.getContext("2d");
        if (!ctx) return;
        const chartSize = RenderEngine.prepareHiDPICanvas(canvas, 300);
        ctx.clearRect(0, 0, chartSize.width, chartSize.height);
      });

      if (this.previewMetricsChart) {
        const metricsCtx = this.previewMetricsChart.getContext("2d");
        if (metricsCtx) {
          const chartSize = RenderEngine.prepareHiDPICanvas(this.previewMetricsChart, 190);
          metricsCtx.clearRect(0, 0, chartSize.width, chartSize.height);
        }
      }

      if (this.previewDifferenceChart) {
        const diffCtx = this.previewDifferenceChart.getContext("2d");
        if (diffCtx) {
          const chartSize = RenderEngine.prepareHiDPICanvas(this.previewDifferenceChart, 190);
          diffCtx.clearRect(0, 0, chartSize.width, chartSize.height);
        }
      }
    }

    downloadPng() {
      ExportEngine.downloadPng(this.canvas);
    }

    bindLessonPresets() {
      this.lessonPresetButtons.forEach((button) => {
        button.addEventListener("click", () => {
          const preset = button.getAttribute("data-preset");
          this.applyPreset(preset);
          this.markActivePresetButton(button);
          this.updatePresetStatus(preset);
          this.handleRun();
          button.blur();
        });
      });
    }

    markActivePresetButton(activeButton) {
      this.lessonPresetButtons.forEach((button) => {
        button.classList.toggle("is-active", button === activeButton);
      });
    }

    updatePresetStatus(preset) {
      if (!this.lessonPresetStatus) return;
      const labels = {
        "sparse-low-attractiveness": "Sparse + Low mobility + Attractiveness",
        "dense-high-attractiveness": "Dense + High mobility + Attractiveness",
        "normal-high-similarity": "Normal + High mobility + Similarity",
      };
      this.lessonPresetStatus.textContent =
        "Preset status: " + (labels[preset] || "custom settings applied") + ".";
    }

    recordRunForComparison(modeLabel) {
      if (!this.state.lastRun || !this.state.lastRun.metrics) return;
      const run = this.state.lastRun;
      this.runHistory.push({
        id: this.nextRunId,
        mode: modeLabel,
        density: run.densityLevel,
        mobility: run.mobilityLevel,
        preference: run.preferenceRule,
        pairCount: run.metrics.pairCount,
        strength: run.metrics.matchingStrength,
        search: run.metrics.averageSearchSteps,
      });
      this.nextRunId += 1;

      if (this.runHistory.length > this.maxRunHistory) {
        this.runHistory = this.runHistory.slice(this.runHistory.length - this.maxRunHistory);
      }

      this.renderRunComparison();
    }

    clearRunComparison() {
      this.runHistory = [];
      this.renderRunComparison();
      this.addChatMessage("Assistant", "Run comparison history cleared.");
    }

    renderRunComparison() {
      if (!this.runComparisonBody) return;

      if (!this.runHistory.length) {
        this.runComparisonBody.innerHTML = "<tr><td colspan=\"6\">No completed runs yet.</td></tr>";
        if (this.runComparisonSummary) {
          this.runComparisonSummary.textContent =
            "Run at least two simulations to compare outcomes side-by-side.";
        }
        return;
      }

      const rows = this.runHistory
        .map((run, index) => {
          const prev = index > 0 ? this.runHistory[index - 1] : null;
          const deltaPairs = prev ? run.pairCount - prev.pairCount : 0;
          const deltaStrength = prev ? run.strength - prev.strength : 0;
          const deltaText = prev
            ? (deltaPairs >= 0 ? "+" : "") +
              deltaPairs +
              " pairs, " +
              (deltaStrength >= 0 ? "+" : "") +
              deltaStrength.toFixed(2) +
              " str"
            : "Baseline";

          return (
            "<tr>" +
            "<td>#" + run.id + "</td>" +
            "<td>" +
            run.density +
            " / " +
            run.mobility +
            " / " +
            run.preference +
            "</td>" +
            "<td>" + run.pairCount + "</td>" +
            "<td>" + run.strength.toFixed(2) + "</td>" +
            "<td>" + run.search.toFixed(1) + "</td>" +
            "<td>" + deltaText + "</td>" +
            "</tr>"
          );
        })
        .join("");

      this.runComparisonBody.innerHTML = rows;

      if (this.runComparisonSummary) {
        const latest = this.runHistory[this.runHistory.length - 1];
        const bestStrength = this.runHistory.reduce((best, run) =>
          run.strength > best.strength ? run : best
        );
        this.runComparisonSummary.textContent =
          "Tracking " +
          this.runHistory.length +
          " recent runs. Latest: " +
          latest.pairCount +
          " pairs, strength " +
          latest.strength.toFixed(2) +
          ". Best strength so far: Run #" +
          bestStrength.id +
          " (" +
          bestStrength.strength.toFixed(2) +
          ").";
      }
    }

    updateSummaryBar() {
      if (!this.state.lastRun || !this.summaryPairs) return;
      const { metrics } = this.state.lastRun;
      this.summaryPairs.textContent = metrics.pairCount + " pairs";
      this.summaryStrength.textContent = "Strength " + metrics.matchingStrength.toFixed(2);
      this.summarySearch.textContent = "Avg search " + metrics.averageSearchSteps.toFixed(1);
      this.runSummary.classList.add("is-visible");
    }

    copyCitation() {
      if (!this.lastCitation) {
        if (this.state.lastRun) {
          const normalizeDensity = (level) =>
            level === "Sparse" ? "Low Density" : level === "Dense" ? "High Density" : "Normal Density";
          const normalizeMobility = (level) =>
            level === "Low" ? "Low Mobility" : level === "High" ? "High Mobility" : "Medium Mobility";
          const moduleMetrics = {
            ...this.state.lastRun.metrics,
            pairs: this.state.pairs,
            agents: this.state.agents,
          };
          this.lastCitation = this.buildRunCitationMessage(
            moduleMetrics,
            normalizeMobility(this.state.lastRun.mobilityLevel),
            normalizeDensity(this.state.lastRun.densityLevel),
            this.state.lastRun.preferenceRule,
            this.state.lastRun.selectivityLevel,
            this.state.lastRun.patienceLevel,
            this.state.lastRun.explorationLevel
          );
        } else {
          this.addChatMessage("Assistant", "Run first, then copy the citation.");
          return;
        }
      }
      
      if (!this.lastCitation) {
        this.addChatMessage("Assistant", "Could not generate citation.");
        return;
      }
      
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(this.lastCitation)
          .then(() => {
            this.addChatMessage("Assistant", "Citation copied.");
          })
          .catch((err) => {
            console.error("Clipboard error:", err);
            this.addChatMessage("Assistant", "Clipboard blocked—copy manually from the chat.");
          });
      } else {
        this.addChatMessage("Assistant", this.lastCitation);
      }
    }

    scrollToTeaching() {
      const teaching = document.querySelector(".panel-teaching");
      if (teaching && teaching.scrollIntoView) {
        teaching.scrollIntoView({ behavior: "smooth", block: "start" });
      }
    }

    applyPreset(preset) {
      const setSelect = (select, value) => {
        if (!select) return;
        select.value = value;
      };

      if (preset === "sparse-low-attractiveness") {
        setSelect(this.densitySelect, "Sparse");
        setSelect(this.mobilitySelect, "Low");
        setSelect(this.preferenceSelect, "Attractiveness-based");
      } else if (preset === "dense-high-attractiveness") {
        setSelect(this.densitySelect, "Dense");
        setSelect(this.mobilitySelect, "High");
        setSelect(this.preferenceSelect, "Attractiveness-based");
      } else if (preset === "normal-high-similarity") {
        setSelect(this.densitySelect, "Normal");
        setSelect(this.mobilitySelect, "High");
        setSelect(this.preferenceSelect, "Similarity-based");
      }
      setSelect(this.selectivitySelect, "Medium");
      setSelect(this.patienceSelect, "Normal");
      setSelect(this.explorationSelect, "Balanced");
      this.state.lastRun = null;
      this.lastCitation = null;
      this.lastTopic = null; // Reset conversation context
      this.lastQuestionType = null;
      this.topicDepth = 0;
      this.setExportEnabled(false);
      this.updateSummaryBarPlaceholder();
      this.renderInsightQuestions();
    }

    updateSummaryBarPlaceholder() {
      if (!this.summaryPairs) return;
      this.summaryPairs.textContent = "— pairs";
      this.summaryStrength.textContent = "Strength —";
      this.summarySearch.textContent = "Avg search —";
      if (this.runSummary) this.runSummary.classList.remove("is-visible");
      if (this.batchSummary) {
        this.batchSummary.textContent = "";
        this.batchSummary.classList.remove("is-visible");
      }
      if (this.csvPreview) {
        this.csvPreview.classList.remove("is-visible");
      }
      this.resetPreviewContent();
    }

    shuffle(items) {
      const copy = [...items];

      for (let index = copy.length - 1; index > 0; index -= 1) {
        const swapIndex = Math.floor(Math.random() * (index + 1));
        [copy[index], copy[swapIndex]] = [copy[swapIndex], copy[index]];
      }

      return copy;
    }

    randomInt(min, max) {
      return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    randomFloat(min, max) {
      return Math.random() * (max - min) + min;
    }

    clamp(value, min, max) {
      return Math.min(max, Math.max(min, value));
    }
  }

// Export class for bootstrap
window.MateChoiceSimulation = MateChoiceSimulation;
