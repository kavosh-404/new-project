/**
 * render.js
 * Canvas rendering for the mate choice simulation
 * Handles all drawing: grid, agents, pairs, charts
 */

class RenderEngine {
  /**
   * Prepare high-DPI canvas (for retina displays)
   */
  static prepareHiDPICanvas(canvas, height) {
    const parentWidth = canvas.parentElement ? canvas.parentElement.clientWidth : 0;
    const width = Math.max(260, Math.floor(parentWidth || canvas.clientWidth || 440));
    const ratio = window.devicePixelRatio || 1;
    canvas.width = Math.floor(width * ratio);
    canvas.height = Math.floor(height * ratio);
    canvas.style.width = "100%";
    canvas.style.height = height + "px";
    const ctx = canvas.getContext("2d");
    if (!ctx) {
      return { width, height };
    }
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.scale(ratio, ratio);
    return { width, height };
  }

  /**
   * Full render of simulation state
   */
  static draw(context, agents, pairs, width, height) {
    context.clearRect(0, 0, width, height);
    this.drawGrid(context, width, height);
    this.drawPairs(context, pairs, agents);
    this.drawAgents(context, agents);
  }

  /**
   * Draw background grid
   */
  static drawGrid(context, width, height) {
    context.fillStyle = "rgba(255, 252, 246, 0.92)";
    context.fillRect(0, 0, width, height);

    context.strokeStyle = "rgba(15, 118, 110, 0.12)";
    context.lineWidth = 1;

    const spacing = Math.max(24, Math.floor(Math.min(width, height) / 18));

    for (let position = 0; position <= width; position += spacing) {
      context.beginPath();
      context.moveTo(position, 0);
      context.lineTo(position, height);
      context.stroke();
    }

    for (let position = 0; position <= height; position += spacing) {
      context.beginPath();
      context.moveTo(0, position);
      context.lineTo(width, position);
      context.stroke();
    }
  }

  /**
   * Draw matched pair connections
   */
  static drawPairs(context, pairs, agents) {
    context.strokeStyle = "#ff4d4d";
    context.lineWidth = 2.5;

    pairs.forEach((pair) => {
      const first = agents[pair.agent1];
      const second = agents[pair.agent2];
      if (!first || !second) return;

      context.beginPath();
      context.moveTo(first.x, first.y);
      context.lineTo(second.x, second.y);
      context.stroke();
    });
  }

  /**
   * Draw individual agents
   */
  static drawAgents(context, agents) {
    agents.forEach((agent) => {
      context.beginPath();
      context.arc(agent.x, agent.y, AGENT_RADIUS, 0, Math.PI * 2);
      context.fillStyle = agent.matched
        ? "#22c55e"
        : this.getAgentColor(agent.attractiveness);
      context.fill();

      context.lineWidth = 1;
      context.strokeStyle = "rgba(31, 26, 23, 0.18)";
      context.stroke();
    });
  }

  /**
   * Get hue-based color for agent attractiveness
   */
  static getAgentColor(attractiveness) {
    const hue = 210 + attractiveness * 1.5;
    const saturation = 70;
    const lightness = 62 - attractiveness * 1.6;
    return "hsl(" + hue + " " + saturation + "% " + lightness + "%)";
  }

  /**
   * Draw bar chart (generic)
   */
  static drawBarChart(ctx, width, height, values, labels, colors) {
    if (!ctx) return;

    ctx.clearRect(0, 0, width, height);
    ctx.fillStyle = "#fdfaf5";
    ctx.fillRect(0, 0, width, height);

    const left = 38;
    const right = width - 16;
    const top = 16;
    const bottom = height - 34;
    const chartWidth = right - left;
    const chartHeight = bottom - top;
    const barGap = 8;
    const barWidth = (chartWidth - barGap * (values.length - 1)) / values.length;

    ctx.strokeStyle = "rgba(79, 57, 36, 0.25)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(left, top);
    ctx.lineTo(left, bottom);
    ctx.lineTo(right, bottom);
    ctx.stroke();

    const maxValue = Math.max(...values, 0.01);

    values.forEach((value, index) => {
      const barHeight = (value / maxValue) * chartHeight;
      const barX = left + index * (barWidth + barGap);
      const barY = bottom - barHeight;

      ctx.fillStyle = colors[index] || "#374151";
      ctx.fillRect(barX, barY, barWidth, barHeight);
    });

    ctx.fillStyle = "#3e352d";
    ctx.font = "11px Instrument Sans, sans-serif";
    ctx.textAlign = "center";

    labels.forEach((label, index) => {
      const x = left + index * (barWidth + barGap) + barWidth / 2;
      ctx.fillText(label, x, bottom + 16);
    });
  }

  /**
   * Draw line chart (generic)
   */
  static drawLineChart(canvas, dataSeries, labels, colors, yAxisLabel, canvasHeight = 260) {
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const chartSize = this.prepareHiDPICanvas(canvas, canvasHeight);
    const width = chartSize.width;
    const height = chartSize.height;

    ctx.clearRect(0, 0, width, height);
    ctx.fillStyle = "#fdfaf5";
    ctx.fillRect(0, 0, width, height);

    const left = 44;
    const right = width - 14;
    const top = 20;
    const bottom = height - 34;
    const chartWidth = right - left;
    const chartHeight = bottom - top;

    // Find max value across all series
    const maxValue = Math.max(
      0.01,
      ...dataSeries.map((series) => Math.max(...series))
    );

    // Draw axes
    ctx.strokeStyle = "rgba(79, 57, 36, 0.25)";
    ctx.beginPath();
    ctx.moveTo(left, top);
    ctx.lineTo(left, bottom);
    ctx.lineTo(right, bottom);
    ctx.stroke();

    // Draw each series
    dataSeries.forEach((series, seriesIndex) => {
      ctx.beginPath();
      ctx.strokeStyle = colors[seriesIndex] || "#374151";
      ctx.lineWidth = 2;

      series.forEach((value, pointIndex) => {
        const x = left + (pointIndex / Math.max(1, series.length - 1)) * chartWidth;
        const y = bottom - (value / maxValue) * chartHeight;
        if (pointIndex === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      });

      ctx.stroke();
    });

    // Draw y-axis label
    ctx.fillStyle = "#3e352d";
    ctx.font = "11px Instrument Sans, sans-serif";
    ctx.textAlign = "left";
    ctx.fillText(yAxisLabel, left + 4, top - 8);
  }

  /**
   * Draw grouped bar chart for figure comparison
   */
  static drawGroupedBars(canvas, data, yLabel, canvasHeight = 300) {
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const chartSize = this.prepareHiDPICanvas(canvas, canvasHeight);
    const width = chartSize.width;
    const height = chartSize.height;

    ctx.clearRect(0, 0, width, height);
    ctx.fillStyle = "#fdfaf5";
    ctx.fillRect(0, 0, width, height);

    const left = 50;
    const right = width - 12;
    const top = 24;
    const bottom = height - 42;
    const chartWidth = right - left;
    const chartHeight = bottom - top;

    const maxValue = Math.max(
      0.01,
      ...data.map((d) => Math.max(d.noRepl, d.repl))
    );

    ctx.strokeStyle = "rgba(79, 57, 36, 0.25)";
    ctx.beginPath();
    ctx.moveTo(left, top);
    ctx.lineTo(left, bottom);
    ctx.lineTo(right, bottom);
    ctx.stroke();

    const groupWidth = chartWidth / data.length;
    const barWidth = Math.max(8, groupWidth * 0.28);
    const gap = Math.max(3, groupWidth * 0.08);

    // Draw bars
    data.forEach((item, index) => {
      const groupStart = left + index * groupWidth + (groupWidth - (2 * barWidth + gap)) / 2;
      const noHeight = (item.noRepl / maxValue) * chartHeight;
      const replHeight = (item.repl / maxValue) * chartHeight;

      ctx.fillStyle = "#374151";
      ctx.fillRect(groupStart, bottom - noHeight, barWidth, noHeight);

      ctx.fillStyle = "#e5e7eb";
      ctx.fillRect(groupStart + barWidth + gap, bottom - replHeight, barWidth, replHeight);

      ctx.strokeStyle = "#6b7280";
      ctx.strokeRect(groupStart + barWidth + gap, bottom - replHeight, barWidth, replHeight);

      ctx.fillStyle = "#3e352d";
      ctx.font = "10px Instrument Sans, sans-serif";
      ctx.textAlign = "center";
      ctx.fillText(item.label, left + index * groupWidth + groupWidth / 2, bottom + 14);
    });

    // Draw legend
    ctx.fillStyle = "#374151";
    ctx.fillRect(right - 130, top + 2, 10, 8);
    ctx.fillStyle = "#3e352d";
    ctx.fillText("No Replacement", right - 116, top + 10);

    ctx.fillStyle = "#e5e7eb";
    ctx.fillRect(right - 130, top + 16, 10, 8);
    ctx.strokeStyle = "#6b7280";
    ctx.strokeRect(right - 130, top + 16, 10, 8);
    ctx.fillStyle = "#3e352d";
    ctx.fillText("Replacement", right - 116, top + 24);
  }

  /**
   * Draw vertical step markers on line charts
   */
  static drawStepMarkers(ctx, left, top, bottom, chartWidth, maxStep, markerSteps) {
    markerSteps.forEach((markerStep) => {
      if (markerStep < 1 || markerStep > maxStep) return;
      const index = markerStep - 1;
      const x = left + (index / Math.max(1, maxStep - 1)) * chartWidth;

      ctx.save();
      ctx.strokeStyle = "rgba(185, 130, 54, 0.36)";
      ctx.lineWidth = 1;
      ctx.setLineDash([4, 4]);
      ctx.beginPath();
      ctx.moveTo(x, top);
      ctx.lineTo(x, bottom);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = "#7a5a3a";
      ctx.font = "10px Instrument Sans, sans-serif";
      ctx.textAlign = "center";
      ctx.fillText("s" + markerStep, x, top - 4);
      ctx.restore();
    });
  }

  /**
   * Draw an empty-state message in a chart canvas
   */
  static drawNoDataChartMessage(canvas, message, height = 260) {
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const chartSize = this.prepareHiDPICanvas(canvas, height);
    ctx.clearRect(0, 0, chartSize.width, chartSize.height);
    ctx.fillStyle = "#fdfaf5";
    ctx.fillRect(0, 0, chartSize.width, chartSize.height);
    ctx.strokeStyle = "rgba(15, 118, 110, 0.2)";
    ctx.setLineDash([6, 4]);
    ctx.strokeRect(12, 12, chartSize.width - 24, chartSize.height - 24);
    ctx.setLineDash([]);
    ctx.fillStyle = "#355c57";
    ctx.font = "13px Instrument Sans, sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(message, chartSize.width / 2, chartSize.height / 2);
  }

  /**
   * Draw hazard line chart and return hover metadata
   */
  static drawHazardChart(canvas, rows, options = {}) {
    const ctx = canvas.getContext("2d");
    if (!ctx) return null;

    const {
      maxStep = 15,
      mode = "line",
      canvasHeight = 260,
      showLegend = false,
      lineWidth = 2.6,
      markerSteps = [5, 10, 15],
      colors = ["#0f766e", "#1d4ed8", "#7c3aed", "#b45309", "#dc2626", "#475569"],
    } = options;

    const chartSize = this.prepareHiDPICanvas(canvas, canvasHeight);
    const width = chartSize.width;
    const height = chartSize.height;

    ctx.clearRect(0, 0, width, height);
    ctx.fillStyle = "#fdfaf5";
    ctx.fillRect(0, 0, width, height);

    const left = 46;
    const right = width - 12;
    const top = 18;
    const bottom = height - 36;
    const chartWidth = right - left;
    const chartHeight = bottom - top;

    const maxHazard = Math.max(
      0.01,
      ...rows.map((row) => Math.max(...row.values.slice(0, maxStep)))
    );

    ctx.strokeStyle = "rgba(79, 57, 36, 0.25)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(left, top);
    ctx.lineTo(left, bottom);
    ctx.lineTo(right, bottom);
    ctx.stroke();

    rows.forEach((row, index) => {
      const values = row.values.slice(0, maxStep);
      const color = colors[index % colors.length];

      ctx.beginPath();
      ctx.strokeStyle = color;
      ctx.lineWidth = lineWidth;

      values.forEach((hazard, stepIndex) => {
        const x = left + (stepIndex / Math.max(1, maxStep - 1)) * chartWidth;
        const y = bottom - (hazard / maxHazard) * chartHeight;
        if (stepIndex === 0) {
          ctx.moveTo(x, y);
        } else if (mode === "step") {
          const prevY = bottom - (values[stepIndex - 1] / maxHazard) * chartHeight;
          ctx.lineTo(x, prevY);
          ctx.lineTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      });
      ctx.stroke();

      if (showLegend) {
        const legendY = top + 16 + index * 14;
        ctx.fillStyle = color;
        ctx.fillRect(right - 162, legendY - 7, 12, 3);
        ctx.fillStyle = "#3e352d";
        ctx.font = "11px Instrument Sans, sans-serif";
        ctx.textAlign = "left";
        ctx.fillText(row.label, right - 146, legendY - 4);
      }
    });

    this.drawStepMarkers(ctx, left, top, bottom, chartWidth, maxStep, markerSteps);

    return {
      left,
      right,
      top,
      bottom,
      chartWidth,
      maxStep,
      series: rows.map((row, index) => ({
        label: row.label,
        color: colors[index % colors.length],
        values: row.values.slice(0, maxStep),
      })),
    };
  }

  /**
   * Draw recreated figure 5/6 grouped bars from analytics rows
   */
  static drawRecreatedGroupedFigure(canvas, rows, noReplacementField, replacementField, yLabel) {
    const data = ["R1-NS", "R1-ZZ", "R1-BR", "R2-NS", "R2-ZZ", "R2-BR"].map((label) => {
      const row = rows.find((item) => item.ruleShort + "-" + item.movement === label);
      return {
        label,
        noRepl: row ? row[noReplacementField] : 0,
        repl: row ? row[replacementField] : 0,
      };
    });

    this.drawGroupedBars(canvas, data, yLabel, 300);
  }

  /**
   * Draw recreated figure 7 hazard trend panel
   */
  static drawRecreatedFigure7(canvas, rows) {
    const maxStep = 15;
    const labels = rows.map((row) => row.ruleShort + "-" + row.movement);
    const dataSeries = rows.map((row) => row.hazardSeries.slice(0, maxStep));
    const colors = ["#0f766e", "#1d4ed8", "#7c3aed", "#b45309", "#dc2626", "#475569"];
    this.drawLineChart(canvas, dataSeries, labels, colors, "Hazard", 300);
  }

  /**
   * Draw run-summary metrics chart
   */
  static drawPreviewMetricsChart(canvas, reportData, stepCount) {
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const chartSize = this.prepareHiDPICanvas(canvas, 190);
    const values = [
      reportData.metrics.pairCount / reportData.maxPairs,
      reportData.metrics.matchingStrength,
      Math.min(1, reportData.metrics.averageSearchSteps / stepCount),
    ];
    const labels = ["Pairs", "Strength", "Search"];
    const colors = ["#0f766e", "#b98236", "#3b6ea8"];
    this.drawBarChart(ctx, chartSize.width, chartSize.height, values, labels, colors);
  }

  /**
   * Draw pair-difference distribution chart
   */
  static drawPreviewDifferenceChart(canvas, pairDifferenceBins) {
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const chartSize = this.prepareHiDPICanvas(canvas, 190);
    const maxCount = Math.max(1, ...pairDifferenceBins);
    const values = pairDifferenceBins.map((count) => count / maxCount);
    const labels = pairDifferenceBins.map((_, index) => String(index));
    const colors = labels.map((_, index) => (index <= 2 ? "#0f766e" : "#6c7a89"));
    this.drawBarChart(ctx, chartSize.width, chartSize.height, values, labels, colors);
  }
}
